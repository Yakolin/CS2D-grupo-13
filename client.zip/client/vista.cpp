#include "vista.h"
#include <QApplication>
#include <QStackedWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QPushButton>
#include <QTabWidget>

Vista::Vista(int& argc, char* argv[])
    : argc(argc), argv(argv), skt(argv[1], argv[2]), protocolo(skt) {}

void Vista::run() {


    QApplication app(argc, argv);  
    MenuView menu(nullptr,protocolo);
    menu.show();

    app.exec();

    /*
    if (resultado == LobbyCommandType::CREATE_GAME || resultado == LobbyCommandType::JOIN_GAME) {
        try {
            GameView gameView(std::move(skt), 500, 500);
            gameView.draw_game();
        } catch (const std::exception& e) {
            std::cerr << e.what() << '\n';
        }
    }
    */

    /*
    // ScoreBoard table;
    // table.show_scores_game(); // funciona, por si querés usarlo más adelante
    */
}

Vista::~Vista() {}
