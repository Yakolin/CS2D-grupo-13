#ifndef GAME_VIEW_H
#define GAME_VIEW_H
#include <fstream>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include <SDL2/SDL.h>

#include "../controller.h"
#include "../tipos.h"

#include "manageTexture.h"
#include "mapView.h"
#include "playerView.h"
#include "renderizable.h"


class GameView {

private:
    Controller controller;
    std::map<char, std::string> leyenda;
    std::map<char, Objet> ids;
    SDL_Window* ventana;
    SDL_Renderer* renderer;
    SDL_Texture* backgroundTexture;
    PlayerView* player;
    SDL_Rect camera;
    ManageTexture manger_texture;
    int width;
    int height;


    bool handle_events(const SDL_Event& evento);

    std::vector<std::vector<char>> cargar_mapa(const std::string& archivo);

    void load_textures();


public:
    explicit GameView(Socket&& skt, const int& width_reseiver, const int& height_reseiver);

    /*
    pre:  width y height deben ser mayores que 0.
    post: devuelve true si la unicializacion salio bien de ventana y renderer.
    */
    bool init_render_window();
    /*
    pre:
    post:
    */
    void draw_game();

    void add_player(PlayerView& player);

    void start();


    ~GameView();
};

#endif  // GAME_VIEW_H
