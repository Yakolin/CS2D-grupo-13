#include "menuView.h"
const int HEIGHT_MENU = 500;
const int WIDTH_MENU = 500;

#define OPCION_CREATE "Create Game"
#define OPCION_JOIN "Join Game"
#define OPCION_EXIT "Exit Game"
#define OPCION_LIST "List Game"
#define OPCION_HELP "Help Game"

MenuView::MenuView(QWidget* parent, ClientProtocol& protocol):
        QWidget(parent),
        stack(this),
        menu(),
        lobby(protocol),
        img_icono(new QLabel(this)),
        clicked_text(),
        botones(),
        protocolo(protocol) ,
        list()
        {
    botones[OPCION_CREATE] = LobbyCommandType::CREATE_GAME;
    botones[OPCION_JOIN] = LobbyCommandType::JOIN_GAME;
    botones[OPCION_LIST] = LobbyCommandType::LIST_GAMES;
    botones[OPCION_EXIT] = LobbyCommandType::EXIT_GAME;
    botones[OPCION_HELP] = LobbyCommandType::HELP_GAME;
    stack.setFixedSize(600, 500);  


    QPixmap img_img("assets/gfx/cs2d.png");
    img_icono->setPixmap(img_img);

    menu.setWindowTitle("Counter Strike");
    resize(WIDTH_MENU, HEIGHT_MENU);


    QWidget *page_create = new QWidget();
    QTabWidget *page_join = new QTabWidget();

    QPushButton* button_menu = new QPushButton("volver a menu");
    QPushButton* button_menu2 = new QPushButton("volver a menu");


    lobby.action_create(page_create, button_menu);
    //std::vector<std::string> list = {"manzana", "banana", "naranja"};
    lobby.action_join(page_join,list, button_menu2);

    stack.addWidget(&menu);         
    stack.addWidget(page_create);  
    stack.addWidget(page_join);    



    QVBoxLayout* layout = new QVBoxLayout(&menu); 
    layout->addWidget(img_icono, 0, Qt::AlignCenter);


    add_button(layout, OPCION_CREATE,[this]() { this->action_create();});
    add_button(layout, OPCION_JOIN,[this]() { this->action_join(); });

    QObject::connect(button_menu, &QPushButton::clicked, this, &MenuView::action_menu);
    QObject::connect(button_menu2, &QPushButton::clicked, this, &MenuView::action_menu);

}


void MenuView::action_exit() {
    QMessageBox::StandardButton answer = QMessageBox::question(nullptr, "Mensaje", "Desea salir?");
    if (answer == QMessageBox::Yes) {
        close();
    }
}
void MenuView::action_create() {
    stack.setCurrentIndex(1);
}
void MenuView::action_join() {
    protocolo.send_lobby_command(LobbyCommandType::LIST_GAMES);
    std::vector<std::string> list = protocolo.read_list_games();
    for (size_t i = 0; i < list.size(); i++) {
    std::cout << list[i] << std::endl;
    }
    this->list = list;
    stack.setCurrentIndex(2);
}
void MenuView::action_menu() {
    stack.setCurrentIndex(0);
}
void MenuView::action_help() {

    QString ayuda = "<b>create game</b><br>"
                    "para crear una nueva partida<br>"
                    "<b>join game</b><br>"
                    "para unirse a una partida existente<br>"
                    "<b>exit</b><br>"
                    "para salir";
    QMessageBox msgBox;
    msgBox.setWindowTitle("Help");
    msgBox.setText(ayuda);

    msgBox.exec();
}

void MenuView::add_button(QVBoxLayout* layout, const QString& text, std::function<void()> callback){
    QPushButton* button = new QPushButton(text);
    button->setFixedSize(200, 50);

    QObject::connect(button, &QPushButton::clicked, [callback,this]() { callback();});

    layout->addWidget(button, 0, Qt::AlignHCenter);
}




LobbyCommandType MenuView::getCommantType() const {
    if (botones.find(clicked_text) != botones.end()) {
        return botones.at(clicked_text);
    }
    return LobbyCommandType::NONE;
}

MenuView::~MenuView() {}

